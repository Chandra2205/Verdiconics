# Verdiconics Portfolio

A personal brand and business idea showcase built with React (Next.js), featuring slide-in navigation and a minimalist white/silver design.
